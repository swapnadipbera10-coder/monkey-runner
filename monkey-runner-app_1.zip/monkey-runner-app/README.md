# 🐒 Monkey Runner — Android App

Endless runner game with 8 seasonal themes and a procedural dance beat.

---

## ✅ How to get your APK (GitHub Actions — free, no Android Studio needed)

### Step 1 — Create a free GitHub account
Go to https://github.com/signup (skip if you already have one)

### Step 2 — Create a new repository
1. Click the **+** button → **New repository**
2. Name it `monkey-runner`
3. Set it to **Public**
4. Click **Create repository**

### Step 3 — Upload these files
On the new repository page, click **uploading an existing file** and drag the entire **contents** of this zip (not the zip itself) into the browser window. Then click **Commit changes**.

The folder structure must be exactly:
```
.github/workflows/build-apk.yml
android/
web/
```

### Step 4 — Watch it build
1. Click the **Actions** tab in your repository
2. You'll see **Build Monkey Runner APK** running (takes ~3–5 minutes)
3. When it turns ✅ green, click on it

### Step 5 — Download your APK
1. Scroll down to **Artifacts**
2. Click **MonkeyRunner-debug** to download the APK
3. Transfer the APK to your Android phone (via Google Drive, WhatsApp, cable — anything)

### Step 6 — Install on your phone
1. On your Android phone, open **Settings → Security** (or Privacy)
2. Enable **Install unknown apps** / **Unknown sources**
3. Open the APK file → **Install**
4. Launch **Monkey Runner** from your home screen! 🐒

---

## 🔑 Optional: Signed Release APK (for sharing)

To get a signed release APK (needed for Google Play), add these secrets to your GitHub repo under **Settings → Secrets → Actions**:

| Secret name | Value |
|---|---|
| `SIGNING_KEY` | Your keystore file, Base64 encoded |
| `KEY_ALIAS` | Your key alias |
| `KEY_STORE_PASSWORD` | Keystore password |
| `KEY_PASSWORD` | Key password |

Generate a keystore with:
```bash
keytool -genkey -v -keystore monkey-runner.jks -keyalg RSA -keysize 2048 -validity 10000 -alias monkeyrunner
base64 -i monkey-runner.jks | pbcopy   # copies to clipboard (macOS)
```

---

## 🎮 Game Features
- 🐒 Animated monkey runner with tail and swinging arms
- 🪨 Stones, 🌲 Trees, 👾 Creatures as obstacles
- 🌟 8 background themes: Day/Night × Summer/Winter/Autumn/Spring
- 🎵 Procedural 128 BPM dance beat with kick, clap, hi-hats & bassline
- 🪙 Collectible coins
- 💾 Best score saved on device
- Full-screen immersive mode, keeps screen on while playing

---

## 🛠 Project structure
```
.github/workflows/    → GitHub Actions CI (builds the APK)
android/              → Native Android project (WebView wrapper)
  app/src/main/
    assets/public/    → Game HTML + JS (bundled into the APK)
    java/             → MainActivity.java (WebView host)
    res/mipmap-*/     → Launcher icons at all DPI sizes
web/                  → Source web files (index.html + game.js)
```
