'use strict';
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const W = 680, H = 300;
let GROUND = H - 50;

function resizeCanvas() {
  const wrap = document.getElementById('canvas-wrap');
  const rect = wrap.getBoundingClientRect();
  const aspect = W / H;
  let cw = rect.width, ch = rect.height;
  if (cw / ch > aspect) { cw = ch * aspect; } else { ch = cw / aspect; }
  canvas.style.width = cw + 'px';
  canvas.style.height = ch + 'px';
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.round(cw * dpr);
  canvas.height = Math.round(ch * dpr);
  ctx.setTransform(canvas.width / W, 0, 0, canvas.height / H, 0, 0);
}
window.addEventListener('resize', resizeCanvas);
window.addEventListener('orientationchange', () => setTimeout(resizeCanvas, 300));

/* ── AUDIO ── */
let audioCtx=null, masterGain=null, soundOn=true, audioStarted=false, beatTimer=null, beatStep=0;
const BPM=128, STEP=60/BPM/2;
const KICK_P=[1,0,0,1,0,0,1,0,1,0,0,1,0,0,1,0];
const CLAP_P=[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0];
const HAT_P =[1,0,1,1,0,1,0,1,1,0,1,1,0,1,0,1];
const BASS_N=[73.4,73.4,82.4,73.4,65.4,65.4,73.4,87.3];
const PLUCK_N=[587,0,659,0,698,0,659,587,0,523,0,587,0,0,0,0];

function initAudio(){
  if(audioStarted)return; audioStarted=true;
  audioCtx=new(window.AudioContext||window.webkitAudioContext)();
  masterGain=audioCtx.createGain(); masterGain.gain.value=0.22;
  masterGain.connect(audioCtx.destination); startBeat();
}
function makeGain(v,t){const g=audioCtx.createGain();g.gain.setValueAtTime(v,t);return g;}
function kick(t){
  const o=audioCtx.createOscillator(),g=makeGain(0.9,t);
  o.type='sine'; o.frequency.setValueAtTime(150,t);
  o.frequency.exponentialRampToValueAtTime(45,t+0.12);
  g.gain.exponentialRampToValueAtTime(0.001,t+0.18);
  o.connect(g);g.connect(masterGain);o.start(t);o.stop(t+0.2);
}
function makeNoise(dur){
  const n=audioCtx.sampleRate*dur,b=audioCtx.createBuffer(1,n,audioCtx.sampleRate),d=b.getChannelData(0);
  for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);
  const s=audioCtx.createBufferSource();s.buffer=b;return s;
}
function clap(t){
  const n=makeNoise(0.08),f=audioCtx.createBiquadFilter(),g=makeGain(0.35,t);
  f.type='bandpass';f.frequency.value=1500;f.Q.value=1.2;
  g.gain.exponentialRampToValueAtTime(0.001,t+0.1);
  n.connect(f);f.connect(g);g.connect(masterGain);n.start(t);n.stop(t+0.1);
}
function hihat(t,open){
  const dur=open?0.18:0.04,n=makeNoise(dur),f=audioCtx.createBiquadFilter(),g=makeGain(open?0.12:0.16,t);
  f.type='highpass';f.frequency.value=7000;
  g.gain.exponentialRampToValueAtTime(0.001,t+dur);
  n.connect(f);f.connect(g);g.connect(masterGain);n.start(t);n.stop(t+dur);
}
function bass(t,freq,dur){
  const o=audioCtx.createOscillator(),f=audioCtx.createBiquadFilter(),g=makeGain(0.001,t);
  o.type='sawtooth';o.frequency.value=freq;f.type='lowpass';f.frequency.value=500;f.Q.value=3;
  g.gain.linearRampToValueAtTime(0.28,t+0.02);g.gain.exponentialRampToValueAtTime(0.001,t+dur);
  o.connect(f);f.connect(g);g.connect(masterGain);o.start(t);o.stop(t+dur+0.02);
}
function pluck(t,freq){
  const o=audioCtx.createOscillator(),f=audioCtx.createBiquadFilter(),g=makeGain(0.001,t);
  o.type='square';o.frequency.value=freq;f.type='bandpass';f.frequency.value=freq*2;f.Q.value=4;
  g.gain.linearRampToValueAtTime(0.14,t+0.01);g.gain.exponentialRampToValueAtTime(0.001,t+0.15);
  o.connect(f);f.connect(g);g.connect(masterGain);o.start(t);o.stop(t+0.16);
}
function schedStep(t,s){
  if(KICK_P[s])kick(t); if(CLAP_P[s])clap(t); if(HAT_P[s])hihat(t,s%4===3);
  if(s%2===0)bass(t,BASS_N[(s/2)|0],STEP*1.9); if(PLUCK_N[s])pluck(t,PLUCK_N[s]);
}
function startBeat(){
  if(beatTimer)clearInterval(beatTimer); beatStep=0;
  let next=audioCtx.currentTime+0.05;
  function sched(){while(next<audioCtx.currentTime+0.15){if(soundOn)schedStep(next,beatStep%16);next+=STEP;beatStep++;}}
  sched(); beatTimer=setInterval(sched,50);
}
function sfx(freq1,freq2,type,vol,dur){
  if(!audioCtx||!soundOn)return;
  const t=audioCtx.currentTime,o=audioCtx.createOscillator(),g=makeGain(vol,t);
  o.type=type; o.frequency.setValueAtTime(freq1,t);
  if(freq2)o.frequency.exponentialRampToValueAtTime(freq2,t+dur*0.6);
  g.gain.exponentialRampToValueAtTime(0.001,t+dur);
  o.connect(g);g.connect(masterGain);o.start(t);o.stop(t+dur+0.01);
}
function playJump(){sfx(420,720,'sine',0.18,0.15);}
function playCoin(){sfx(880,1320,'square',0.12,0.18);}
function playDie(){sfx(220,60,'sawtooth',0.16,0.45);}

document.getElementById('sound-btn').addEventListener('click',()=>{
  soundOn=!soundOn;
  document.getElementById('sound-btn').textContent=soundOn?'🔊 Sound on':'🔇 Sound off';
  if(masterGain)masterGain.gain.value=soundOn?0.22:0;
});

/* ── THEMES ── */
const THEMES=[
  {label:'☀️ Day · Summer',  isDay:true, season:'summer',sky:['#87CEEB','#FFFDE7'],ground:'#5D8A3C',groundLine:'#3B6D11',grass:'#639922',sunMoon:'#FFD600',smGlow:'rgba(255,214,0,0.18)',starA:0},
  {label:'❄️ Day · Winter',  isDay:true, season:'winter',sky:['#D0E8F5','#EAF4FB'],ground:'#C8DFF0',groundLine:'#A8C8E0',grass:'#B0D0E8',sunMoon:'#FFFDE7',smGlow:'rgba(255,255,220,0.22)',starA:0},
  {label:'🍂 Day · Autumn',  isDay:true, season:'autumn',sky:['#F9C97C','#FFEAA0'],ground:'#8B5E3C',groundLine:'#6B3F1C',grass:'#C17A2A',sunMoon:'#FF8C00',smGlow:'rgba(255,140,0,0.2)',starA:0},
  {label:'🌸 Day · Spring',  isDay:true, season:'spring',sky:['#B5E8F7','#E8F8FF'],ground:'#6DBF67',groundLine:'#3B9A34',grass:'#8FD45A',sunMoon:'#FFE066',smGlow:'rgba(255,224,102,0.18)',starA:0},
  {label:'🌙 Night · Summer',isDay:false,season:'summer',sky:['#0D1B3E','#1A2D5A'],ground:'#1a3a1a',groundLine:'#0f2a0f',grass:'#27500A',sunMoon:'#FFFDE7',smGlow:'rgba(255,253,231,0.13)',starA:0.9},
  {label:'❄️ Night · Winter',isDay:false,season:'winter',sky:['#0A1628','#1A2840'],ground:'#8faec0',groundLine:'#6a90a8',grass:'#9ab8cc',sunMoon:'#C8D8F0',smGlow:'rgba(200,216,240,0.15)',starA:0.8},
  {label:'🍂 Night · Autumn',isDay:false,season:'autumn',sky:['#1A0E05','#2E1A08'],ground:'#4a2a10',groundLine:'#2a1208',grass:'#7a3e18',sunMoon:'#D4A020',smGlow:'rgba(212,160,32,0.14)',starA:0.75},
  {label:'🌸 Night · Spring',isDay:false,season:'spring',sky:['#0E1A2E','#1C2D44'],ground:'#1a3a1a',groundLine:'#0d260d',grass:'#2a5a2a',sunMoon:'#E8F0FF',smGlow:'rgba(232,240,255,0.12)',starA:0.85},
];
let themeIdx=0, themeTimer=0, transAlpha=0, inTrans=false;
const THEME_DUR=60*60;
function T(){return THEMES[themeIdx];}

/* ── GAME STATE ── */
let state='idle', score=0, best=parseInt(localStorage.getItem('mrBest')||'0'), frame=0, speed=4, jumpCount=0;
const runner={x:90,y:0,w:26,h:34,vy:0,trail:[]};
let obstacles=[],coins=[],stars=[],particles=[],snow=[],leafArr=[],petals=[];
document.getElementById('best').textContent=best;

function initStars(){stars=[];for(let i=0;i<80;i++)stars.push({x:Math.random()*W,y:Math.random()*(GROUND-10),r:Math.random()*1.5+0.3,a:Math.random()*Math.PI*2});}
function initSnow(){snow=[];for(let i=0;i<45;i++)snow.push({x:Math.random()*W,y:Math.random()*GROUND,r:Math.random()*3+1,sp:Math.random()*0.8+0.3,sw:Math.random()*2-1});}
function initLeaves(){leafArr=[];for(let i=0;i<32;i++)leafArr.push({x:Math.random()*W,y:Math.random()*GROUND,r:Math.random()*5+3,sp:Math.random()+0.5,sw:Math.random()*2-1,rot:Math.random()*Math.PI*2,col:['#D85A30','#EF9F27','#BA7517','#A32D2D'][Math.floor(Math.random()*4)]});}
function initPetals(){petals=[];for(let i=0;i<38;i++)petals.push({x:Math.random()*W,y:Math.random()*GROUND,r:Math.random()*4+2,sp:Math.random()*0.7+0.3,sw:Math.random()*2-1,rot:Math.random()*Math.PI*2,col:['#F4C0D1','#ED93B1','#FBEAF0','#ffb8d0'][Math.floor(Math.random()*4)]});}

function setup(){GROUND=H-50;runner.y=GROUND;initStars();initSnow();initLeaves();initPetals();}

function resetGame(){
  runner.y=GROUND;runner.vy=0;jumpCount=0;runner.trail=[];
  obstacles=[];coins=[];particles=[];
  score=0;frame=0;speed=4;themeTimer=0;state='running';
}

function jump(){
  initAudio();
  if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume();
  if(state==='idle'||state==='dead'){resetGame();return;}
  if(jumpCount<2){runner.vy=jumpCount===0?-13:-11;jumpCount++;spawnParts(runner.x+runner.w/2,runner.y+runner.h,'#7a5230',8);playJump();}
}

function spawnParts(x,y,col,n){for(let i=0;i<n;i++)particles.push({x,y,vx:(Math.random()-0.5)*4,vy:-Math.random()*3-1,life:1,col});}

/* ── OBSTACLES ── */
function drawStone(x,y,w,h){
  const t=T();
  ctx.fillStyle='rgba(0,0,0,0.25)';ctx.beginPath();ctx.ellipse(x+w/2,y+h+3,w/2,5,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#888780';ctx.beginPath();
  ctx.moveTo(x+w*0.15,y+h);ctx.bezierCurveTo(x,y+h*0.7,x,y+h*0.3,x+w*0.2,y+h*0.05);
  ctx.bezierCurveTo(x+w*0.4,y-h*0.05,x+w*0.7,y-h*0.05,x+w*0.9,y+h*0.1);
  ctx.bezierCurveTo(x+w+4,y+h*0.4,x+w,y+h*0.8,x+w*0.85,y+h);
  ctx.closePath();ctx.fill();
  ctx.fillStyle='#B4B2A9';ctx.beginPath();ctx.ellipse(x+w/2-w*0.1,y+h*0.3,w*0.2,h*0.15,-0.4,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#5F5E5A';ctx.lineWidth=1.2;
  ctx.beginPath();ctx.moveTo(x+w/2,y+h*0.2);ctx.lineTo(x+w/2+4,y+h*0.5);ctx.lineTo(x+w/2+1,y+h*0.8);ctx.stroke();
  if(t.season==='winter'){ctx.fillStyle='rgba(220,235,255,0.85)';ctx.beginPath();ctx.ellipse(x+w/2,y+h*0.08,w*0.35,h*0.14,0,0,Math.PI*2);ctx.fill();}
}
function drawTree(x,y,w,h){
  const t=T(),tw=w*0.28,th=h*0.38,tx=x+w/2-tw/2,ty=y+h-th;
  ctx.fillStyle='rgba(0,0,0,0.2)';ctx.beginPath();ctx.ellipse(x+w/2,y+h+3,w/2,5,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#633806';ctx.beginPath();ctx.roundRect(tx,ty,tw,th+2,2);ctx.fill();
  const fc=t.season==='winter'?['#8faec0','#a8c8e0','#c8dff0']:t.season==='autumn'?['#8B3A0F','#C17A2A','#D85A30']:t.season==='spring'?['#5DBB63','#8FD45A','#C8F09A']:['#27500A','#3B6D11','#639922'];
  for(let i=0;i<3;i++){
    const r=1-i*0.22,lw=w*r*1.05,lh=h*0.42,lx=x+w/2-lw/2,ly=y+(h-th)*0.6-i*lh*0.55;
    ctx.fillStyle=fc[i];ctx.beginPath();ctx.moveTo(lx+lw/2,ly);ctx.lineTo(lx+lw,ly+lh);ctx.lineTo(lx,ly+lh);ctx.closePath();ctx.fill();
  }
  if(t.season==='winter'){
    ctx.fillStyle='rgba(220,235,255,0.7)';
    const lw=w*1.05,lh=h*0.42,lx=x+w/2-lw/2,ly=y+(h-th)*0.6;
    ctx.beginPath();ctx.moveTo(lx+lw/2,ly+2);ctx.lineTo(lx+lw*0.78,ly+lh*0.35);ctx.lineTo(lx+lw*0.22,ly+lh*0.35);ctx.closePath();ctx.fill();
  }
}
function drawCreature(x,y,w,h,anim){
  const cx=x+w/2,ay=Math.sin(anim*0.12)*5,ly=Math.sin(anim*0.18)*4;
  ctx.fillStyle='rgba(0,0,0,0.25)';ctx.beginPath();ctx.ellipse(cx,y+h+4,w/2,6,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#3C3489';ctx.beginPath();ctx.ellipse(cx,y+h*0.62,w*0.44,h*0.38,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#534AB7';ctx.beginPath();ctx.ellipse(cx,y+h*0.25,w*0.36,h*0.28,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#D85A30';
  ctx.beginPath();ctx.moveTo(cx-w*0.2,y+h*0.08);ctx.lineTo(cx-w*0.32,y-h*0.08);ctx.lineTo(cx-w*0.12,y+h*0.06);ctx.closePath();ctx.fill();
  ctx.beginPath();ctx.moveTo(cx+w*0.2,y+h*0.08);ctx.lineTo(cx+w*0.32,y-h*0.08);ctx.lineTo(cx+w*0.12,y+h*0.06);ctx.closePath();ctx.fill();
  ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(cx-w*0.13,y+h*0.22,5,6,0,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.ellipse(cx+w*0.13,y+h*0.22,5,6,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#E24B4A';ctx.beginPath();ctx.ellipse(cx-w*0.13,y+h*0.23,3,4,0,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.ellipse(cx+w*0.13,y+h*0.23,3,4,0,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#AFA9EC';ctx.lineWidth=1.5;
  ctx.beginPath();ctx.moveTo(cx-w*0.12,y+h*0.36);ctx.quadraticCurveTo(cx,y+h*0.42,cx+w*0.12,y+h*0.36);ctx.stroke();
  ctx.fillStyle='#534AB7';
  ctx.beginPath();ctx.ellipse(cx-w*0.52,y+h*0.58+ay,w*0.14,h*0.1,-0.4,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.ellipse(cx+w*0.52,y+h*0.58-ay,w*0.14,h*0.1,0.4,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#3C3489';
  ctx.beginPath();ctx.ellipse(cx-w*0.2,y+h*0.92+ly,w*0.13,h*0.1,0.2,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.ellipse(cx+w*0.2,y+h*0.92-ly,w*0.13,h*0.1,-0.2,0,Math.PI*2);ctx.fill();
}

function spawnObstacle(){
  const types=['stone','stone','tree','tree','creature'],type=types[Math.floor(Math.random()*types.length)];
  let w,h;
  if(type==='stone'){w=30+Math.random()*22;h=24+Math.random()*20;}
  else if(type==='tree'){w=34+Math.random()*18;h=52+Math.random()*22;}
  else{w=46+Math.random()*18;h=60+Math.random()*20;}
  obstacles.push({x:W+20,y:GROUND+runner.h-h,w,h,type,anim:0});
}
function spawnCoin(){coins.push({x:W+20,y:GROUND-45-Math.random()*65,r:8});}

/* ── UPDATE ── */
function update(){
  frame++;speed=4+score*0.004;
  document.getElementById('spd').textContent=speed.toFixed(1)+'x';
  themeTimer++;
  if(themeTimer>=THEME_DUR){
    themeTimer=0;themeIdx=(themeIdx+1)%THEMES.length;
    document.getElementById('theme-badge').textContent=THEMES[themeIdx].label;
    inTrans=true;transAlpha=1;
  }
  if(inTrans){transAlpha-=0.025;if(transAlpha<=0){transAlpha=0;inTrans=false;}}
  runner.vy+=0.75;runner.y+=runner.vy;
  if(runner.y>=GROUND){runner.y=GROUND;runner.vy=0;jumpCount=0;}
  runner.trail.push({x:runner.x+runner.w/2,y:runner.y+runner.h/2});
  if(runner.trail.length>10)runner.trail.shift();
  if(frame%Math.max(52,88-score*0.3)===0)spawnObstacle();
  if(frame%80===0)spawnCoin();
  stars.forEach(s=>s.a+=0.025);
  const season=T().season;
  if(season==='winter')snow.forEach(f=>{f.y+=f.sp;f.x+=Math.sin(frame*0.02+f.sw)*0.5;if(f.y>GROUND+runner.h)f.y=0;});
  if(season==='autumn')leafArr.forEach(l=>{l.y+=l.sp;l.x+=Math.sin(frame*0.015+l.sw)*0.8;l.rot+=0.03;if(l.y>GROUND+runner.h)l.y=0;});
  if(season==='spring')petals.forEach(p=>{p.y+=p.sp;p.x+=Math.sin(frame*0.02+p.sw)*0.6;p.rot+=0.02;if(p.y>GROUND+runner.h)p.y=0;});
  for(let i=obstacles.length-1;i>=0;i--){
    obstacles[i].x-=speed;obstacles[i].anim++;
    if(obstacles[i].x+obstacles[i].w<0){obstacles.splice(i,1);score+=10;continue;}
    if(hit(runner,obstacles[i])){die();return;}
  }
  for(let i=coins.length-1;i>=0;i--){
    coins[i].x-=speed;
    if(coins[i].x<-20){coins.splice(i,1);continue;}
    const c=coins[i];
    if(Math.hypot(runner.x+runner.w/2-c.x,runner.y+runner.h/2-c.y)<runner.w/2+c.r){
      score+=5;spawnParts(c.x,c.y,'#EF9F27',10);coins.splice(i,1);playCoin();
    }
  }
  for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.x+=p.vx;p.y+=p.vy;p.vy+=0.15;p.life-=0.05;if(p.life<=0)particles.splice(i,1);}
  score+=0.05;
  document.getElementById('score').textContent=Math.floor(score);
}
function hit(a,b){return a.x+4<b.x+b.w&&a.x+a.w-4>b.x&&a.y+4<b.y+b.h&&a.y+a.h-2>b.y;}
function die(){
  state='dead';spawnParts(runner.x+runner.w/2,runner.y+runner.h/2,'#7a5230',20);
  if(Math.floor(score)>best){best=Math.floor(score);localStorage.setItem('mrBest',best);}
  document.getElementById('best').textContent=best;playDie();
}

/* ── DRAW ── */
function drawSky(){
  const t=T(),g=ctx.createLinearGradient(0,0,0,GROUND+runner.h);
  g.addColorStop(0,t.sky[0]);g.addColorStop(1,t.sky[1]);ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
}
function drawSunMoon(){
  const t=T(),sx=W-70,sy=38;
  ctx.fillStyle=t.smGlow;ctx.beginPath();ctx.arc(sx,sy,30,0,Math.PI*2);ctx.fill();
  ctx.fillStyle=t.sunMoon;ctx.beginPath();ctx.arc(sx,sy,17,0,Math.PI*2);ctx.fill();
  if(t.isDay&&t.season!=='winter'){
    ctx.strokeStyle=t.sunMoon;ctx.lineWidth=2.8;ctx.lineCap='round';
    for(let a=0;a<8;a++){const ang=a*Math.PI/4+frame*0.005;ctx.beginPath();ctx.moveTo(sx+Math.cos(ang)*22,sy+Math.sin(ang)*22);ctx.lineTo(sx+Math.cos(ang)*30,sy+Math.sin(ang)*30);ctx.stroke();}
  }
  if(!t.isDay){ctx.fillStyle=t.sky[0];ctx.beginPath();ctx.arc(sx+7,sy-5,13,0,Math.PI*2);ctx.fill();}
}
function drawClouds(){
  const t=T(),col=t.isDay?'rgba(255,255,255,0.78)':'rgba(255,255,255,0.1)';
  const off=frame*0.28%W;
  [[80,30,52],[230,22,42],[410,36,62],[590,26,46]].forEach(([bx,by,r])=>{
    const cx=(bx-off+W)%W;ctx.fillStyle=col;
    ctx.beginPath();ctx.ellipse(cx,by,r,r*0.55,0,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.ellipse(cx-r*0.5,by+4,r*0.6,r*0.4,0,0,Math.PI*2);ctx.fill();
    ctx.beginPath();ctx.ellipse(cx+r*0.5,by+4,r*0.6,r*0.4,0,0,Math.PI*2);ctx.fill();
  });
}
function drawGround(){
  const t=T();
  ctx.fillStyle=t.ground;ctx.fillRect(0,GROUND+runner.h,W,H-GROUND-runner.h);
  ctx.fillStyle=t.groundLine;ctx.fillRect(0,GROUND+runner.h,W,2);
  for(let gx=(frame*speed*0.5%52);gx<W;gx+=52){
    if(t.season==='winter'){ctx.fillStyle='rgba(220,235,255,0.6)';ctx.beginPath();ctx.arc(gx,GROUND+runner.h+5,4.5,0,Math.PI*2);ctx.fill();}
    else{ctx.fillStyle=t.grass;ctx.fillRect(gx,GROUND+runner.h,3,5);ctx.fillRect(gx+7,GROUND+runner.h,2,3);}
  }
}
function drawStars(){
  const t=T();if(t.starA<=0)return;
  stars.forEach(s=>{const a=((Math.sin(s.a)+1)/2)*t.starA;ctx.fillStyle=`rgba(255,253,231,${a*0.9})`;ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill();});
}
function drawSeasonFX(){
  const s=T().season;
  if(s==='winter'){ctx.fillStyle='rgba(200,220,255,0.85)';snow.forEach(f=>{ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,Math.PI*2);ctx.fill();});}
  if(s==='autumn')leafArr.forEach(l=>{ctx.save();ctx.translate(l.x,l.y);ctx.rotate(l.rot);ctx.fillStyle=l.col;ctx.beginPath();ctx.ellipse(0,0,l.r,l.r*0.6,0,0,Math.PI*2);ctx.fill();ctx.restore();});
  if(s==='spring')petals.forEach(p=>{ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rot);ctx.fillStyle=p.col;ctx.beginPath();ctx.ellipse(0,0,p.r,p.r*0.55,0,0,Math.PI*2);ctx.fill();ctx.restore();});
}
function drawMonkey(){
  const rx=runner.x,ry=runner.y,rw=runner.w,rh=runner.h,cx=rx+rw/2;
  runner.trail.forEach((t,i)=>{const a=(i/runner.trail.length)*0.25;ctx.fillStyle='#8a5f3a'+Math.floor(a*255).toString(16).padStart(2,'0');ctx.beginPath();ctx.arc(t.x,t.y,(i/runner.trail.length)*10,0,Math.PI*2);ctx.fill();});
  const air=runner.y<GROUND,ls=air?0:Math.sin(frame*0.4)*9,as=air?0:-Math.sin(frame*0.4)*11,bb=air?-2:Math.abs(Math.sin(frame*0.4))*1.5,tw=Math.sin(frame*0.25)*7;
  ctx.strokeStyle='#7a5230';ctx.lineWidth=4.5;ctx.lineCap='round';
  ctx.beginPath();ctx.moveTo(rx+2,ry+rh*0.55-bb);ctx.quadraticCurveTo(rx-11,ry+rh*0.4+tw,rx-9,ry+rh*0.15+tw);ctx.stroke();
  ctx.lineWidth=5.5;
  ctx.beginPath();ctx.moveTo(cx-3,ry+rh*0.8-bb);ctx.lineTo(cx-3+ls*0.4,ry+rh+10);ctx.stroke();
  ctx.fillStyle='#5c4023';ctx.beginPath();ctx.ellipse(cx-3+ls*0.4,ry+rh+12,4.5,2.8,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#8a5f3a';ctx.beginPath();ctx.ellipse(cx,ry+rh*0.55-bb,rw*0.42,rh*0.4,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#D9C2A0';ctx.beginPath();ctx.ellipse(cx+1,ry+rh*0.62-bb,rw*0.26,rh*0.26,0,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#7a5230';ctx.lineWidth=5.5;
  ctx.beginPath();ctx.moveTo(cx+4,ry+rh*0.82-bb);ctx.lineTo(cx+4-ls*0.4,ry+rh+10);ctx.stroke();
  ctx.fillStyle='#5c4023';ctx.beginPath();ctx.ellipse(cx+4-ls*0.4,ry+rh+12,4.5,2.8,0,0,Math.PI*2);ctx.fill();
  ctx.lineWidth=5;
  ctx.beginPath();ctx.moveTo(cx-rw*0.3,ry+rh*0.42-bb);ctx.lineTo(cx-rw*0.3-as*0.3,ry+rh*0.42-bb+13);ctx.stroke();
  const hy=ry+rh*0.18-bb;
  ctx.fillStyle='#8a5f3a';ctx.beginPath();ctx.ellipse(cx,hy,rw*0.37,rh*0.31,0,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.ellipse(cx-rw*0.35,hy-2,5.5,6.5,0,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.ellipse(cx+rw*0.35,hy-2,5.5,6.5,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#D9C2A0';
  ctx.beginPath();ctx.ellipse(cx-rw*0.35,hy-2,2.8,3.5,0,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.ellipse(cx+rw*0.35,hy-2,2.8,3.5,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#E8D7B8';ctx.beginPath();ctx.ellipse(cx+2,hy+5,rw*0.25,rh*0.19,0,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#2C2C2A';ctx.beginPath();ctx.arc(cx-3.5,hy,2.5,0,Math.PI*2);ctx.fill();
  ctx.beginPath();ctx.arc(cx+9,hy,2.5,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#4A3520';ctx.beginPath();ctx.ellipse(cx+3,hy+8.5,2.6,1.8,0,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#7a5230';ctx.lineWidth=5.5;
  ctx.beginPath();ctx.moveTo(cx+rw*0.3,ry+rh*0.4-bb);
  if(air)ctx.lineTo(cx+rw*0.58,ry+rh*0.13-bb);
  else ctx.lineTo(cx+rw*0.3+as*0.3,ry+rh*0.4-bb+13);
  ctx.stroke();
}
function drawOverlay(){
  if(state==='idle'){
    ctx.fillStyle='rgba(0,0,0,0.55)';ctx.fillRect(0,0,W,H);
    ctx.fillStyle='#D9A05B';ctx.font='600 30px sans-serif';ctx.textAlign='center';
    ctx.fillText('🐒 Monkey Runner',W/2,H/2-24);
    ctx.fillStyle='#E8D7B8';ctx.font='15px sans-serif';
    ctx.fillText('8 seasonal themes — every 60s!',W/2,H/2+6);
    ctx.fillStyle='#B4B2A9';ctx.font='14px sans-serif';
    ctx.fillText('Tap anywhere to start',W/2,H/2+32);
  } else if(state==='dead'){
    ctx.fillStyle='rgba(0,0,0,0.65)';ctx.fillRect(0,0,W,H);
    ctx.fillStyle='#E24B4A';ctx.font='600 26px sans-serif';ctx.textAlign='center';
    ctx.fillText('The monkey tumbled! 🐒',W/2,H/2-22);
    ctx.fillStyle='#F09595';ctx.font='15px sans-serif';
    ctx.fillText('Score: '+Math.floor(score)+'   Best: '+best,W/2,H/2+8);
    ctx.fillStyle='#AFA9EC';ctx.font='14px sans-serif';
    ctx.fillText('Tap to try again',W/2,H/2+36);
  }
}
function draw(){
  ctx.clearRect(0,0,W,H);
  drawSky();drawStars();drawSunMoon();drawClouds();drawSeasonFX();drawGround();
  coins.forEach(c=>{
    const b=Math.sin(frame*0.1+c.x)*3;
    ctx.fillStyle='#EF9F27';ctx.beginPath();ctx.arc(c.x,c.y+b,c.r,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#FAC775';ctx.beginPath();ctx.arc(c.x-2,c.y+b-2,3.5,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle='#BA7517';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(c.x,c.y+b,c.r,0,Math.PI*2);ctx.stroke();
  });
  obstacles.forEach(o=>{
    if(o.type==='stone')drawStone(o.x,o.y,o.w,o.h);
    else if(o.type==='tree')drawTree(o.x,o.y,o.w,o.h);
    else drawCreature(o.x,o.y,o.w,o.h,o.anim);
  });
  particles.forEach(p=>{ctx.globalAlpha=p.life;ctx.fillStyle=p.col;ctx.beginPath();ctx.arc(p.x,p.y,3.5,0,Math.PI*2);ctx.fill();});
  ctx.globalAlpha=1;
  if(state!=='dead')drawMonkey();
  if(inTrans&&transAlpha>0){ctx.fillStyle=`rgba(255,255,255,${transAlpha*0.35})`;ctx.fillRect(0,0,W,H);}
  if(state==='running'){
    const pct=1-themeTimer/THEME_DUR;
    ctx.fillStyle='rgba(0,0,0,0.28)';ctx.fillRect(0,H-5,W,5);
    const t=T();ctx.fillStyle=t.isDay?'rgba(255,220,80,0.85)':'rgba(150,180,255,0.85)';
    ctx.fillRect(0,H-5,W*pct,5);
  }
  drawOverlay();
}
function loop(){if(state==='running')update();draw();requestAnimationFrame(loop);}

/* ── INPUT ── */
canvas.addEventListener('touchstart',e=>{e.preventDefault();jump();},{passive:false});
canvas.addEventListener('mousedown',jump);
document.addEventListener('keydown',e=>{if(e.code==='Space'||e.code==='ArrowUp'){e.preventDefault();jump();}});

resizeCanvas();setup();loop();
